import wx
import os
import sys
import nbt

main_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'nbt')
sys.path.append(main_dir)


class Mywin(wx.Frame):

    def __init__(self, parent, title):
        super(Mywin, self).__init__(parent, title=title, size=(800, 600))
        self.panel = wx.Panel(self)
        self._sizer = wx.BoxSizer(wx.VERTICAL)

        self.size = ["360", "720", "1440", "2880", "5760", "11520", "23040", "46080"]
        self.choos = wx.ListBox(self.panel, size=(80, 130), pos=(50, 70), choices=self.size)
        self.btn = wx.StaticText(self.panel, size=(200, 50), pos=(5, 0), label="Select the size of\n the cassette")
        font = wx.Font(18, wx.ROMAN, wx.ITALIC, wx.NORMAL)
        self.btn.SetFont(font)

        self.remap = ["1.0.5 - 1.6.0.13", "1.6.0.14-1.16.100.03", "1.16.100.04-latest version"]
        self.cho = wx.ListBox(self.panel, size=(160, 50), pos=(260, 70), choices=self.remap)
        self.btn = wx.StaticText(self.panel, size=(160, 50), pos=(260, 0), label="Select your version \n of minecraft")

        font = wx.Font(18, wx.ROMAN, wx.ITALIC, wx.NORMAL)
        self.btn.SetFont(font)

        self.c = ["to_schematic"]
        self.choose = wx.Choice(self.panel, size=(1, 1), pos=(-100, 0), choices=self.c)

        self.remover = ["remover"]
        self.choose = wx.Choice(self.panel, size=(1, 1), pos=(-100, 0), choices=self.remover)

        self.choose.SetSelection(0)
        self.apply = wx.Button(self.panel, size=(800, 60), pos=(0, 500), label="Create a video cassette")
        self.apply.Bind(wx.EVT_BUTTON, self.run)
        self._sizer.Add(self.choose)

        self.btn = wx.StaticText(self.panel, size=(800, 50), pos=(10, 200),
                                 label="\nMap Art Video cassettes editor v 0.0.2 GUI \nall rights reserved \ncreate by Max_RM and PremiereHell, 14.09.2021")
        font = wx.Font(18, wx.ROMAN, wx.ITALIC, wx.NORMAL)
        self.btn.SetFont(font)

        self.panel.SetSizer(self._sizer)

        self.btn = wx.StaticText(self.panel, size=(480, 50), pos=(500, 0), label="Enter the starting uuid")
        font = wx.Font(18, wx.ROMAN, wx.ITALIC, wx.NORMAL)
        self.btn.SetFont(font)
        self.inputID = wx.TextCtrl(
            self.panel, style=wx.TE_LEFT | wx.TE_BESTWRAP, size=(100, 20), pos=(490, 70),
        )

        self.panel.Fit()
        self.Show(True)

    def run(self, pl):
        file = self.choos.GetString(self.choos.GetSelection()) + ".schematic"
        NBT = nbt.nbt.NBTFile(file)
        UserNumber = self.inputID.GetValue()
        for x in range(0, len(NBT['TileEntities'])):
            if 'Item' in NBT['TileEntities'][x]:
                if 'tag' in NBT['TileEntities'][x]['Item']:
                    if 'map_uuid' in NBT['TileEntities'][x]['Item']['tag']:
                        number = str(NBT['TileEntities'][x]['Item']['tag']['map_uuid'])
                        num = int(str(number)) + int(UserNumber)
                        NBT['TileEntities'][x]['Item']['tag']['map_uuid'] = nbt.nbt.TAG_Long(num)

                    if 'Name' in NBT['TileEntities'][x]['Item']:

                        if self.cho.GetString(self.cho.GetSelection()) == "1.0.5 - 1.6.0.13":
                            mapID = 358
                            NBT['TileEntities'][x]['Item'].pop('Name')
                            NBT['TileEntities'][x]['Item']['id'] = nbt.nbt.TAG_Short(mapID)

                        if self.cho.GetString(self.cho.GetSelection()) == "1.6.0.14-1.16.100.03":
                            mapID = "minecraft:map"
                            NBT['TileEntities'][x]['Item']['Name'] = nbt.nbt.TAG_String(mapID)

                        if self.cho.GetString(self.cho.GetSelection()) == "1.16.100.04-latest version":
                            mapID = "minecraft:filled_map"
                            NBT['TileEntities'][x]['Item']['Name'] = nbt.nbt.TAG_String(mapID)

        with wx.FileDialog(self, "Save Schematic", wildcard="Schematic (*.schematic)|*.schematic",
                           style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT) as fileDialog:

            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return
            pathname = fileDialog.GetPath()
        NBT.write_file(pathname)


ex = wx.App()
Mywin(None, 'Map Art Video cassettes editor v 0.0.2 GUI ')
ex.MainLoop()
